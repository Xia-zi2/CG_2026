#pragma once

#include <imgui.h>

#include <memory>
#include <vector>

#include "shapes/shape.h"
#include "common/widget.h"

namespace USTC_CG
{

// Canvas class for drawing shapes.
class Canvas : public Widget
{
   public:
    // Inherits constructor from Component.
    using Widget::Widget;

    // Override the draw method from the parent Component class.
    void draw() override;

    // Enumeration for supported shape types.
    enum ShapeType
    {
        kDefault = 0,
        kLine = 1,
        kRect = 2,
        kEllipse = 3,
        kPolygon = 4,
        kPen = 5,
        kFreehand =6,
        kSelect = 7
    };
    
    // Shape type setters.
    void set_default();
    void set_line();
    void set_rect();
    void set_ellipse();
    void set_polygon();
    void set_pen();
    void set_freehand();
    // HW1_TODO: more shape types.

    // Clears all shapes from the canvas.
    void clear_shape_list();

    // Set canvas attributes (position and size).
    void set_attributes(const ImVec2& min, const ImVec2& size);

    //Pass to input to sides_.
    void set_polygon_sides(int sides);

    // Controls the visibility of the canvas background.
    void show_background(bool flag);

    //Style
    void set_stroke_enabled(bool enabled);
    void set_line_thickness(float thickness);
    void set_line_color(const float color[4]);
    void set_fill_enabled(bool enabled);
    void set_fill_color(const float color[4]);

    //Select
    void set_select();

   private:
    // Drawing functions.
    void draw_background();
    void draw_shapes();

    // Event handlers for mouse interactions.
    void mouse_click_event();
    void mouse_move_event();
    void mouse_release_event();
    void mouse_right_click_event();
    void mouse_double_click_event();
    // Calculates mouse's relative position in the canvas.
    ImVec2 mouse_pos_in_canvas() const;

    // Canvas attributes.
    ImVec2 canvas_min_;         // Top-left corner of the canvas.
    ImVec2 canvas_max_;         // Bottom-right corner of the canvas.
    ImVec2 canvas_size_;        // Size of the canvas.
    bool draw_status_ = false;  // Is the canvas currently being drawn on.

    ImVec2 canvas_minimal_size_ = ImVec2(50.f, 50.f);
    ImU32 background_color_ = IM_COL32(50, 50, 50, 255);
    ImU32 border_color_ = IM_COL32(255, 255, 255, 255);
    bool show_background_ = true;  // Controls background visibility.

    // Mouse interaction status.
    bool is_hovered_, is_active_;

    // Current shape being drawn.
    ShapeType shape_type_;
    int polygon_sides_ = 3;
    ImVec2 start_point_, end_point_;
    std::shared_ptr<Shape> current_shape_;
    Shape::Config current_style_;

    // List of shapes drawn on the canvas.
    std::vector<std::shared_ptr<Shape>> shape_list_;
    int selected_shape_index_ = -1;
};

}  // namespace USTC_CG
